myId = null;

function sendMessageToController(dataPayload) {
  if (!myId) return;
  chrome.runtime.sendMessage({
    target: "TO_CONTENT",
    fromId: myId,
    data: dataPayload
  });
}

function onCommunicationReceived(data) {
    if (data.command === "") {
        
    }
}

wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

chrome.runtime.onMessage.addListener(async (msg) => {
  if (msg.type === "INIT_WORKER") {
    myId = msg.id;
    if(myId == "blooket-tst"){
        const initData = msg.data;
        const nameInput = document.querySelector('.Form_longInput__Kyk9e');
        if (nameInput) {
            await wait(200);      
            nameInput.value="toString";
            await wait(100);
            submitEl=document.querySelector('.FormSubmitButton_submitButton__MK2LJ');
            submitEl.click();

            
        }
    }
  }
  
  if (msg.type === "COMMUNICATION") {
    onCommunicationReceived(msg.data);
  }
});